$(document).on('shiny:inputchanged', function(event) {
       if (event.name === 'click' || event.name === 'select_species' || event.name === 'select_biovar1' ||
       event.name === 'select_biovar2' || event.name === 'nextpage' || event.name === 'select_soilvar2' || event.name === 'select_soilvar1') {
         _paq.push(['trackEvent', 'input',
           'updates', event.name, event.value]);
       }
     });
