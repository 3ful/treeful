
Für jede Baumart kannst du hier die Wohlfühlzone des Baums erkunden. Die Wolke in den Grafiken zeigt wo der Baum vorkommt, je nachdem welche Klima-Variablen ausgewählt sind. 

Sinnvolle Kombinationen der Variable:
* BIO01 (Jahresdurchschnittstemperatur) und BIO12 (Jahresniederschlag)
* BIO05 (Temperatur im wärmsten Monat) und BIO14 (Niederschlag im tockensten Monat)
